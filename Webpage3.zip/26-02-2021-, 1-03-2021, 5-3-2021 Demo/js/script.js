/*slider js start*/
$(document).ready(function(){
  
  $(".main-banner-slider").slick({
    autoplay:true,
    autoplaySpeed:10000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:true,
    pauseOnDotsHover:true,
    cssEase:'linear',   
    draggable:false,
    prevArrow:'<button class="PrevArrow"></button>',
    nextArrow:'<button class="NextArrow"></button>', 
  });
  
})
/*slider js end*/

/*Services slider js start*/

$('.responsive').slick({
  dots: false,
    prevArrow: $('.prev'),
    nextArrow: $('.next'),
  infinite: false,
  speed: 300,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 1600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }   
  ]
});

/*Services slider js end*/

/*Testnomial slider js start*/

const authorsEl = document.querySelectorAll('.author');
const container = document.querySelector('.testimonials-container');
const nameEl = document.querySelector('.name');
const textEl = document.querySelector('.text');

const testimonials = [{
    name: 'Lorem ipsum dolor sit amet consectetr adipicing elit usmod tempor incidunt enim minim quis nostrud nis exer tation ullamco laboris nis aliquip commodo per',
    color: '#253b71'
},{
    name: 'Lorem ipsum dolor sit amet consectetr adipicing elit usmod tempor commodo per',
    
},{
    name: 'Lorem ipsum dolor sit amet consectetr adipicing elit usmod tempor incidunt enim minim quis nostrud nis exer tation ullamco laboris nis aliquip commodo per',
   
},{
    name: 'Lorem ipsum dolor sit amet consectetr ullamco laboris nis aliquip commodo per',
    
},{
    name: 'Lorem ipsum dolor sit amet consectetr adipicing elit usmod tempor incidunt enim minim quis nostrud nis exer tation ullamco laboris nis aliquip commodo per',
}];

addTestimonial(0);

authorsEl.forEach((author, idx) => {
    author.addEventListener('click', (e) => {
        addTestimonial(idx);
        author.classList.add('selected');
    })
});

function addTestimonial(idx) {
    const testimonial = testimonials[idx];
    
    nameEl.innerHTML = testimonial.name;
    textEl.innerHTML = testimonial.text;
    container.style.background = testimonial.color;
    container.style.boxShadow = `0 35px 10px -20px ${testimonial.color.substring(0, testimonial.color.length-4)}0.9)`;
    
    authorsEl.forEach(author => {
        author.classList.remove('selected');
    });
}

/*testnomial js end*/

/*faq js start*/
$(document).ready(function(){
    $(".accordion-title").click(function(e){
        var accordionitem = $(this).attr("data-tab");
        $("#"+accordionitem).slideToggle().parent().siblings().find(".accordion-content").slideUp();

        $(this).toggleClass("active-title");
        $("#"+accordionitem).parent().siblings().find(".accordion-title").removeClass("active-title");

        $("i.fa-chevron-down",this).toggleClass("chevron-top");
        $("#"+accordionitem).parent().siblings().find(".accordion-title i.fa-chevron-down").removeClass("chevron-top");
    });
    
});
/*faq js end*/

